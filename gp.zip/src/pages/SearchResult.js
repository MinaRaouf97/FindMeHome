



const SearchResult = () =>{


}



export default SearchResult;